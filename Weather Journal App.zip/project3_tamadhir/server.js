let projectData = {};

// Require Express to run server and routes
const express = require('express');
const bodyParser = require('body-parser')

//start up an instance of app 
const app = express();


//dependencies
// const { info } = require("console");
// const { retreive } = require("path");

//setup server
const PORT = 9900;

const baseURI = "https://api.openweathermap.org/data/2.5/weather?zip=";
//pars the json files coming from the client side....

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));


//Cors for cross origin allowance
const cors = require('cors');

app.use(cors());
//intialize the main project folder
app.use(express.static('website'));

// post route
app.post("/add", async function(req, res){
    const body = await req.body;
    projectData = body;
    console.log(projectData);
    res.status(200).send(projectData); 
});


app.get("/all", async (req, res) => {
    console.log(projectData);
    res.send(projectData);

});

//callback to debug
app.listen(PORT,() =>{
    console.log('Server is runing on Port ' + PORT);
});

