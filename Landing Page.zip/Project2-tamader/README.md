# Landing Page Project

## Table of content

- [Landing Page Project](#landing-page-project)
  - [Table of content](#table-of-content)
  - [Usage](#usage)
  - [Dependencies](#dependencies)

## Usage

When the user clicks on the menu, for example, the shop option, the page automatically moves him to the shopping section, and so on in the rest of the options and sections. In addition, the arrow button takes the user to the beginning of the page.


## Dependencies
1. Home.
2. About.
3. Shop.
4. Contact.