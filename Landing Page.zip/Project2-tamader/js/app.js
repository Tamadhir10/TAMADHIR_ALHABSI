// navbar list
// // Select the container element
const navbarContainer = document.querySelector('.nav');

// Create navbar elements
const homeLink = document.createElement('a');
homeLink.href = '#home';
homeLink.textContent = 'Home';

const aboutLink = document.createElement('a');
aboutLink.href = '#about';
aboutLink.textContent = 'About';

const shopLink = document.createElement('a');
shopLink.href = '#shop';
shopLink.textContent = 'Shop';

const contactLink = document.createElement('a');
contactLink.href = '#contact';
contactLink.textContent = 'Contact';



// Append elements to the navbar container
navbarContainer.appendChild(homeLink);
navbarContainer.appendChild(aboutLink);
navbarContainer.appendChild(shopLink);
navbarContainer.appendChild(contactLink);



// Add event listeners to the nav links to handle click events
const navLinks = document.querySelectorAll('nav ul li a');
navLinks.forEach(link => {
  link.addEventListener('click', (event) => {
    event.preventDefault();
    const targetSection = document.querySelector(link.getAttribute('href'));
    setActiveSection(targetSection);
  });
});

// Add event listener to handle click outside the sections
document.addEventListener('click', (event) => {
  const clickedElement = event.target;
  const sections = document.querySelectorAll('section');

  sections.forEach(e => {
    const isOutsideSections = !e.contains(clickedElement)
    if (isOutsideSections) {
      
      removeActiveSections();
    }
  });

});

// Add event listener to handle scroll and highlight active section in the nav bar
window.addEventListener('scroll', () => {
  const sections = document.querySelectorAll('section');
  let currentSection = sections[0];
  sections.forEach(section => {
    const rect = section.getBoundingClientRect();
    if (rect.top >= 0 && rect.top < window.innerHeight) {
      currentSection = section;
    }
  });
  setActiveNavLink(currentSection);
});

// Function to set the active section
function setActiveSection(section) {
  removeActiveSections();
  section.classList.add('active');
}

// Function to remove active state from all sections
function removeActiveSections() {
  const sections = document.querySelectorAll('section');
  sections.forEach(section => {
    section.classList.remove('active');
  });
}

// Function to set the active link in the nav bar
function setActiveNavLink(section) {
  removeActiveNavLinks();
  const navLinks = document.querySelectorAll('nav ul li a');
  navLinks.forEach(link => {
    if (link.getAttribute('href') === `#${section.id}`) {
      link.classList.add('active');
    }
  });
}

// Function to remove active state from all nav links
function removeActiveNavLinks() {
  const navLinks = document.querySelectorAll('nav ul li a');
  navLinks.forEach(link => {
    link.classList.remove('active');
  });
}